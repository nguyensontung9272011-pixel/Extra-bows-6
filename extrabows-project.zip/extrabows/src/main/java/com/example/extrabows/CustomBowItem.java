package com.example.extrabows;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.event.EventHooks;
import org.jetbrains.annotations.Nullable;

public class CustomBowItem extends BowItem {
    public static final int USE_DURATION = 72000; // same value as vanilla BowItem
    public static final String MULTI_TAG = "extrabows_multi";
    /** Angle (degrees) between neighbouring arrows of a multi shot. */
    public static final float SPREAD_DEGREES = 5.0F;

    @FunctionalInterface
    public interface FlatDamage {
        /** @param power 0..1 (1 = full draw) @return damage added to the vanilla-equivalent damage */
        float get(float power);
    }

    private final int drawTicks;
    private final float velocityMult;
    private final int arrowsPerShot;
    private final FlatDamage flatDamage;
    private final float damageMult;
    private final boolean requireFullDraw;

    public CustomBowItem(Properties props, int drawTicks, float velocityMult, int arrowsPerShot,
                         FlatDamage flatDamage, float damageMult, boolean requireFullDraw) {
        super(props);
        this.drawTicks = drawTicks;
        this.velocityMult = velocityMult;
        this.arrowsPerShot = arrowsPerShot;
        this.flatDamage = flatDamage;
        this.damageMult = damageMult;
        this.requireFullDraw = requireFullDraw;
    }

    public int getDrawTicks() {
        return drawTicks;
    }

    private float powerFor(int charge) {
        float f = (float) charge / drawTicks;
        f = (f * f + f * 2.0F) / 3.0F; // same curve as vanilla, stretched over drawTicks
        return Math.min(f, 1.0F);
    }

    @Override
    public int getDefaultProjectileRange() {
        return Math.max(1, Math.round(15 * velocityMult));
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        // "click" sound the moment a full-draw-only bow becomes ready
        if (requireFullDraw && !level.isClientSide && USE_DURATION - remaining == drawTicks) {
            level.playSound(null, entity.getX(), entity.getY(), entity.getZ(),
                    SoundEvents.CROSSBOW_LOADING_END, SoundSource.PLAYERS, 1.0F, 1.0F);
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (!(entity instanceof Player player)) return;
        ItemStack ammo = player.getProjectile(stack);
        if (ammo.isEmpty()) return;

        int charge = USE_DURATION - timeLeft;
        charge = EventHooks.onArrowLoose(stack, level, player, charge, true);
        if (charge < 0) return;

        if (requireFullDraw && charge < drawTicks) return; // not fully drawn: nothing happens, no ammo used

        float power = powerFor(charge);
        if (power < 0.1F) return;

        List<ItemStack> projectiles = draw(stack, ammo, player); // uses up ONE arrow
        if (level instanceof ServerLevel server && !projectiles.isEmpty()) {
            List<ItemStack> volley = new ArrayList<>(projectiles);
            while (volley.size() < arrowsPerShot) {
                volley.add(projectiles.get(0).copy());
            }
            this.shoot(server, player, player.getUsedItemHand(), stack, volley,
                    power * 3.0F * velocityMult, 1.0F, false, null); // false = no crit arrows
        }

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ARROW_SHOOT, SoundSource.PLAYERS, 1.0F,
                1.0F / (level.getRandom().nextFloat() * 0.4F + 1.2F) + power * 0.5F);
        player.awardStat(Stats.ITEM_USED.get(this));
    }

    @Override
    protected void shootProjectile(LivingEntity shooter, Projectile projectile, int index,
                                   float velocity, float inaccuracy, float angle,
                                   @Nullable LivingEntity target) {
        // Multi shot: fan the arrows out (middle one goes straight)
        float fan = arrowsPerShot > 1
                ? (index - (arrowsPerShot - 1) / 2.0F) * SPREAD_DEGREES
                : angle;
        super.shootProjectile(shooter, projectile, index, velocity, inaccuracy, fan, target);

        if (projectile instanceof AbstractArrow arrow && velocity > 0.0F) {
            float power = Mth.clamp(velocity / (3.0F * velocityMult), 0.0F, 1.0F);

            // Damage a vanilla bow would deal at this draw (includes Power enchant)
            double vanillaDamage = arrow.getBaseDamage() * (velocity / velocityMult);
            double wanted = Math.max(1.0D, (vanillaDamage + flatDamage.get(power)) * damageMult);
            // Arrow damage = ceil(speed * baseDamage); the -0.02 stops float error rounding up
            arrow.setBaseDamage(Math.max(0.01D, (wanted - 0.02D) / velocity));

            if (arrowsPerShot > 1) arrow.addTag(MULTI_TAG);
            if (index > 0) arrow.pickup = AbstractArrow.Pickup.DISALLOWED; // only 1 arrow can be picked up
        }
    }
}
