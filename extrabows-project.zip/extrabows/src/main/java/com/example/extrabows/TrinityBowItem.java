package com.example.extrabows;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.EventHooks;
import org.joml.Vector3f;

public class TrinityBowItem extends BowItem {
    public static final int DRAW_TICKS = 30;          // 1.5 s
    public static final float VELOCITY_MULT = 1.5F;   // same as the long bow
    public static final int SHOT_DELAY_TICKS = 1;      // time between the 6 shots of a barrage
    public static final float LASER_SPEED_MULT = 3.0F; // laser speed (the long bow arrow is 1.5)
    public static final float BONUS_DAMAGE = 0.0F;    // same as a vanilla arrow (6) per laser

    private static final DustParticleOptions GOLD =
            new DustParticleOptions(new Vector3f(1.0F, 0.82F, 0.15F), 1.2F);

    public TrinityBowItem(Properties props) {
        super(props);
    }

    @Override
    public int getDefaultProjectileRange() {
        return Math.round(15 * VELOCITY_MULT);
    }

    private static float powerFor(int charge) {
        float f = (float) charge / DRAW_TICKS;
        f = (f * f + f * 2.0F) / 3.0F;
        return Math.min(f, 1.0F);
    }

    private static double handSide(LivingEntity entity) {
        return (entity.getUsedItemHand() == InteractionHand.MAIN_HAND)
                == (entity.getMainArm() == HumanoidArm.RIGHT) ? 1.0D : -1.0D;
    }

    /** Beams of light rushing in to a point; the cloud shrinks as the bow charges. */
    public static void chargeParticles(Level level, Vec3 tip, float progress) {
        RandomSource r = level.getRandom();
        if (r.nextInt(2) == 0) { // one converging streak every other tick
            double radius = 0.9D * (1.0F - progress) + 0.12D;
            Vec3 dir = new Vec3(r.nextGaussian(), r.nextGaussian(), r.nextGaussian()).normalize();
            Vec3 start = tip.add(dir.scale(radius));
            Vec3 vel = dir.scale(-0.1D);
            level.addParticle(ParticleTypes.END_ROD, start.x, start.y, start.z, vel.x, vel.y, vel.z);
        }
        if (progress >= 1.0F && r.nextInt(3) == 0) { // a little glow once fully charged
            level.addParticle(GOLD, tip.x, tip.y, tip.z, 0, 0, 0);
        }
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        int charge = CustomBowItem.USE_DURATION - remaining;
        float progress = Math.min(1.0F, charge / (float) DRAW_TICKS);
        if (level.isClientSide) {
            Vec3 look = entity.getLookAngle();
            Vec3 right = look.cross(new Vec3(0.0D, 1.0D, 0.0D)).normalize();
            Vec3 tip = entity.getEyePosition().add(look.scale(1.0D))
                    .add(right.scale(0.3D * handSide(entity))).add(0.0D, -0.25D, 0.0D);
            chargeParticles(level, tip, progress);
        } else if (charge == DRAW_TICKS) {
            level.playSound(null, entity.getX(), entity.getY(), entity.getZ(),
                    SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0F, 1.5F);
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (!(entity instanceof Player player)) return;
        ItemStack ammo = player.getProjectile(stack);
        if (ammo.isEmpty()) return; // still needs an arrow in the inventory (any kind, it is used up)

        int charge = CustomBowItem.USE_DURATION - timeLeft;
        charge = EventHooks.onArrowLoose(stack, level, player, charge, true);
        if (charge < 0) return;

        float power = powerFor(charge);
        if (power < 0.1F) return;

        List<ItemStack> used = draw(stack, ammo, player); // consumes one arrow (unless Infinity/creative)
        if (level instanceof ServerLevel server && !used.isEmpty()) {
            fireBarrage(server, player, power, stack);
            EquipmentSlot slot = player.getUsedItemHand() == InteractionHand.MAIN_HAND
                    ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND;
            stack.hurtAndBreak(1, player, slot);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0F, 1.6F);
        player.awardStat(Stats.ITEM_USED.get(this));
    }

    /** One laser from the bow in hand, then one from each floating bow, 2 ticks apart (6 in total). */
    private void fireBarrage(ServerLevel level, Player player, float power, ItemStack bow) {
        ItemStack weapon = bow.copy(); // copied before the bow takes damage; used for Power / Punch
        for (int i = 0; i <= SpiritBow.COUNT; i++) {
            final int index = i;
            if (i == 0) {
                fireOne(level, player, power, weapon, 0);
            } else {
                BowEvents.schedule(i * SHOT_DELAY_TICKS, () -> fireOne(level, player, power, weapon, index));
            }
        }
    }

    private static void fireOne(ServerLevel level, Player player, float power, ItemStack weapon, int index) {
        if (!player.isAlive() || player.level() != level) return;

        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 right = look.cross(new Vec3(0.0D, 1.0D, 0.0D)).normalize();

        Vec3 origin;
        if (index == 0) {
            origin = eye.add(look.scale(0.8D)).add(right.scale(0.3D * handSide(player))).add(0.0D, -0.2D, 0.0D);
        } else {
            SpiritBow s = SpiritManager.getSlot(player, index - 1);
            if (s == null) return;
            origin = s.position().add(look.scale(0.5D));
        }

        // every bow aims at the point the crosshair is on right now
        Vec3 target = eye.add(look.scale(40.0D));
        Vec3 dir = index == 0 ? look : target.subtract(origin).normalize();

        float speed = power * 3.0F * LASER_SPEED_MULT;
        double wanted = 6.0D * power + BONUS_DAMAGE; // vanilla bow = 6 at full draw

        LaserArrow laser = new LaserArrow(level, player, weapon);
        laser.setPos(origin.x, origin.y, origin.z);
        laser.setBaseDamage(Math.max(0.01D, (wanted - 0.05D) / speed));
        laser.shoot(dir.x, dir.y, dir.z, speed, 0.0F);
        level.addFreshEntity(laser);

        level.playSound(null, origin.x, origin.y, origin.z, SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS,
                0.5F, 1.4F + level.getRandom().nextFloat() * 0.4F);
    }
}
