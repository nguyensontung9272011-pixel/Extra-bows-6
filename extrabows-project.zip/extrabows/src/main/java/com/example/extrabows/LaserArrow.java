package com.example.extrabows;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Golden "blast laser" fired only by the Trinity Bow. Not an item, can't be picked up. */
public class LaserArrow extends AbstractArrow {
    /** Max flight time (14 ticks at ~9 blocks/tick = about a long bow's range). */
    public static final int MAX_FLIGHT_TICKS = 14;
    private static final DustParticleOptions GOLD =
            new DustParticleOptions(new Vector3f(1.0F, 0.82F, 0.15F), 1.4F);

    private double flightSpeed = 0.0D;

    public LaserArrow(EntityType<? extends LaserArrow> type, Level level) {
        super(type, level);
        init();
    }

    public LaserArrow(Level level, LivingEntity owner, ItemStack bow) {
        super(ExtraBows.LASER_ARROW.get(), owner, level, new ItemStack(Items.ARROW), bow);
        init();
    }

    private void init() {
        this.setNoGravity(true);
        this.pickup = AbstractArrow.Pickup.DISALLOWED;
    }

    @Override
    protected ItemStack getDefaultPickupItem() {
        return new ItemStack(Items.ARROW);
    }

    @Override
    public void tick() {
        if (flightSpeed == 0.0D) {
            flightSpeed = getDeltaMovement().length();
        }
        super.tick();

        if (level().isClientSide) {
            double dx = getX() - xo, dy = getY() - yo, dz = getZ() - zo;
            for (int i = 0; i < 4; i++) { // thin golden streak
                double t = i / 4.0D;
                level().addParticle(GOLD, xo + dx * t, yo + dy * t, zo + dz * t, 0, 0, 0);
            }
        } else if (tickCount > MAX_FLIGHT_TICKS) {
            discard();
            return;
        }

        // lasers don't slow down: keep the speed constant so damage is constant
        Vec3 v = getDeltaMovement();
        if (flightSpeed > 0.0D && v.lengthSqr() > 1.0E-6D && !isRemoved()) {
            setDeltaMovement(v.normalize().scale(flightSpeed));
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        burst();
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        burst();
        if (!level().isClientSide) discard();
    }

    private void burst() {
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.END_ROD, getX(), getY(), getZ(), 3, 0.1, 0.1, 0.1, 0.03);
        }
    }
}
