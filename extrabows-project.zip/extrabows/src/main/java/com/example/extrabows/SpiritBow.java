package com.example.extrabows;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

/** A purple bow that floats above the shoulder of a player who holds the Trinity Bow. */
public class SpiritBow extends Entity {
    private static final EntityDataAccessor<Optional<UUID>> OWNER =
            SynchedEntityData.defineId(SpiritBow.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final DustParticleOptions GOLD =
            new DustParticleOptions(new Vector3f(1.0F, 0.82F, 0.15F), 1.0F);

    public static final int COUNT = 5;

    // fixed spot on the arch over the owner (0 = right side, 0.5 = above the head, 1 = left side)
    private static final double[] START = {0.5D, 0.0D, 1.0D, 0.25D, 0.75D};
    private static final double[] DIR = {1.0D, 1.0D, -1.0D, -1.0D, 1.0D};

    private int slot = 0; // 0..COUNT-1 (server only)

    public SpiritBow(EntityType<? extends SpiritBow> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public void setup(Player owner, int slot) {
        this.entityData.set(OWNER, Optional.of(owner.getUUID()));
        this.slot = slot;
    }

    public int getSlot() {
        return slot;
    }

    @Nullable
    public Player getOwner() {
        Optional<UUID> id = this.entityData.get(OWNER);
        return id.isPresent() ? level().getPlayerByUUID(id.get()) : null;
    }

    private static double triangle(double x) {
        double m = ((x % 2.0D) + 2.0D) % 2.0D;
        return m <= 1.0D ? m : 2.0D - m;
    }

    /**
     * Every bow slides back and forth along an arch over the owner's head (one sweep = 3 s).
     * Some go right-to-left while others go left-to-right, so they keep passing each other
     * and swapping places.
     */
    public Vec3 anchor(Player owner) {
        double yaw = Math.toRadians(owner.getYRot());
        Vec3 fwd = new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
        Vec3 right = new Vec3(-Math.cos(yaw), 0.0D, -Math.sin(yaw));

        double theta = Math.PI * START[slot];
        double cy = owner.getBbHeight() * 0.8D;

        return owner.position()
                .add(right.scale(Math.cos(theta) * 1.35D))
                .add(fwd.scale(-0.15D))
                .add(0.0D, cy + Math.sin(theta) * 1.0D, 0.0D);
    }

    @Override
    public void tick() {
        super.tick();
        Player owner = getOwner();

        if (!level().isClientSide) {
            if (owner == null || !owner.isAlive() || !SpiritManager.isHoldingTrinity(owner)) {
                discard();
                return;
            }
            // glide toward the shoulder (looks like it flies out of the bow in hand)
            Vec3 np = position().lerp(anchor(owner), 0.5D);
            setPos(np.x, np.y, np.z);
            setYRot(owner.getYRot());
            setXRot(owner.getXRot());
        }
        if (level().isClientSide && tickCount % 3 == 0 && owner != null && owner.isUsingItem()
                && owner.getUseItem().getItem() instanceof TrinityBowItem) {
            float progress = Math.min(1.0F, owner.getTicksUsingItem() / (float) TrinityBowItem.DRAW_TICKS);
            Vec3 f = Vec3.directionFromRotation(getXRot(), getYRot());
            TrinityBowItem.chargeParticles(level(), position().add(f.scale(0.45D)), progress);
        }
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(OWNER, Optional.empty());
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }
}
